import sys
#import cv2
import os
#import glob

j = 4
for i in range(1256, 1353):
	name = "img_" + str(i) +".jpg"
	if (i%2 ==0):
		rename = "img_" + str(j) +".jpg"
		j+=1
	else:
		rename = "img_" + str(j) +".jpg"
		j+=1
	os.rename(name, rename)